package com.example.retrofit_meizi;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

public class MeiziAdapter extends RecyclerView.Adapter<MeiziViewHolder> {
    private Context mContext;
    private List<MeiziBean> mMeiziList;
    private LayoutInflater mLayoutInflater;
    private OnItemActionListener mOnItemActionListener;

    public interface OnItemActionListener {
        void onItemClick(View view, int position);
        boolean onItemLongClick(View view, int position);
    }

    public void setOnItemActionListener(OnItemActionListener onItemActionListener) {
        this.mOnItemActionListener = onItemActionListener;
    }

    public MeiziAdapter(Context mContext, List<MeiziBean> mMeiziList) {
        this.mContext = mContext;
        this.mMeiziList = mMeiziList;
        mLayoutInflater =LayoutInflater.from(mContext);
    }

    @Override
    public MeiziViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = mLayoutInflater.inflate(R.layout.meizi_detail_layout, parent, false);
        MeiziViewHolder meiziViewHolder = new MeiziViewHolder(v);

        return meiziViewHolder;
    }

    @Override
    public void onBindViewHolder(final MeiziViewHolder holder, int position) {
        String url = mMeiziList.get(position).img_url;

        holder.imageView.setImageResource(R.mipmap.ic_launcher);
        holder.imageView.setTag(url);

        // onclick event
        if (mOnItemActionListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int layoutPosition = holder.getLayoutPosition();
                    mOnItemActionListener.onItemClick(holder.itemView, layoutPosition);
                }
            });

            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int layoutPosition = holder.getLayoutPosition();
                    mOnItemActionListener.onItemLongClick(holder.itemView, layoutPosition);
                    return false;
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mMeiziList.size();
    }
}

class MeiziViewHolder extends RecyclerView.ViewHolder {
    public ImageView imageView;
    public MeiziViewHolder(View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.girl_image);
    }
}
