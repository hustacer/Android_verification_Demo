package com.example.retrofit_meizi;

import android.os.AsyncTask;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private List<MeiziBean> mMeiziList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recyView);

        new MeiziAsyncTask().execute();
    }

    class MeiziAsyncTask extends AsyncTask<Void, Void, List<MeiziBean>> {
        @Override
        protected List<MeiziBean> doInBackground(Void... voids) {
            return mMeiziList;
        }

        @Override
        protected void onPostExecute(List<MeiziBean> meiziBeans) {
            super.onPostExecute(meiziBeans);

            MeiziAdapter meiziAdapter = new MeiziAdapter(MainActivity.this, meiziBeans);
            mRecyclerView.setAdapter( meiziAdapter );
            meiziAdapter.setOnItemActionListener(new MeiziAdapter.OnItemActionListener() {
                @Override
                public void onItemClick(View view, int position) {
                    Toast.makeText(MainActivity.this, "-单击-" + position, Toast.LENGTH_SHORT).show();
                }

                @Override
                public boolean onItemLongClick(View view, int position) {
                    Toast.makeText(MainActivity.this, "-长按-" + position, Toast.LENGTH_SHORT).show();
                    return false;
                }
            });
        }
    }


    private void request(String sWord) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://gank.io/api/") // 设置 网络请求 Url
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        GetRequest_Interface request = retrofit.create(GetRequest_Interface.class);

        // http://fy.iciba.com/ajax.php?a=fy&f=auto&t=auto&w=hello%20world
        Call<Translation> call = request.getCall("fy", "auto", "auto", sWord);

        call.enqueue(new Callback<Translation>() {
            @Override
            public void onResponse(Call<Translation> call, Response<Translation> response) {
                Log.d(TAG, ""+ "连接成功");
                mOutWord = response.body().show();
                Log.d(TAG, "body = "+ mOutWord);
                Message message = mHandler.obtainMessage();
                message.what = 1;
                message.obj = mOutWord;
                mHandler.sendMessage(message);
            }

            @Override
            public void onFailure(Call<Translation> call, Throwable t) {
                Log.d(TAG, ""+ "连接失败");
            }
        });
    }
}