package com.example.retrofit_meizi;

public class MeiziBean {
    public String img_url;
}