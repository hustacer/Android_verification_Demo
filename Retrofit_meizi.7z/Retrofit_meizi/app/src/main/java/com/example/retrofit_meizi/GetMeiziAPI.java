package com.example.retrofit_meizi;

import android.database.Observable;

import retrofit2.http.GET;
import retrofit2.http.Path;

public interface GetMeiziAPI {
    // http://gank.io/api/data/%E7%A6%8F%E5%88%A9/10/1
    @GET("data/%E7%A6%8F%E5%88%A9/{count}/{page}")
    Observable<Meizi> latest(@Path("count") int count, @Path("page") int page);
}